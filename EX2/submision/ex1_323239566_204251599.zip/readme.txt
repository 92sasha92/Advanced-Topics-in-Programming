if both players don't have moving pieces we print th following reason: 
  "A tie - All moving PIECEs of both players are eaten"