#include "BattleInfo.h"


std::string BattleInfo::getId1() {
    return this->id1;
}

std::string BattleInfo::getId2() {
    return this->id2;
}

bool BattleInfo::getIsAlgo1BattleCount() {
    return this->isAlgo1BattleCount;
}

bool BattleInfo::getIsAlgo2BattleCount() {
    return this->isAlgo2BattleCount;
}